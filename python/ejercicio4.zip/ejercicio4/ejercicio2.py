# Desarrollar un programa que muestre la tabla de multiplicar del 5 (del 5 al 50)
i = 1
tabla = 5
for i in range(1,11):
    print(str(tabla) + " x " + str(i) + " = " + str(tabla*i))
