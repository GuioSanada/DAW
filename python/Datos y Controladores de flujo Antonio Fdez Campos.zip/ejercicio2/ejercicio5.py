# Inicializar un string con la cadena "hOlA" luego llamar a sus métodos
# upper(), lower() y capitalize(), guardar los datos retornados en otros string
# y mostrarlos por pantalla.

cad = "hOlA"
cadUpper = cad.upper()
cadLower = cad.lower()
cadCapitalice = cad.capitalize()

print("Upper: " + cadUpper)
print("Lower " + cadLower)
print("Capitalize " + cadCapitalice)
