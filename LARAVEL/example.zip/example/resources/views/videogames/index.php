<h1>Listado de videojuegos</h1>

<table>
    <tr>
        <th>Nombre</th>
        <th>Precio</th>
    </tr>
    <?php

        foreach($videogames as $videogame){
            list ($name, $price) = $videogame;
            echo "<tr>";
                echo "<td>$name</td>";
                echo "<td>$price</td>";
            echo '</tr>';
        }
    ?>
</table>